<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Relicarium</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/indexStyle.css" />
    <link rel="icon" href="images/losangolo.png" type="image/png" />
  </head>

   <body style="background-color: black; color: red">

  <!-- abrindo navbar -->
    <header>
      <nav>

        <a class="logo" >RELICARIUM</a>
        <div class="mobile-menu">
          <div class="line1"></div>
          <div class="line2"></div>
          <div class="line3"></div>
        </div>

        <ul class="nav-list">
          <li class="dropdown">
            <a href="index.php">Home</a>
        </li>
        <li class="dropdown">
        <a class="dropbtn" href="fichaOrdem.php">Ficha</a>
        </li>
         <li class="dropdown">
        <a class="dropbtn" href="pericias.php">Perícias</a>
        </li>
      <li class="dropdown" >
      <a class="dropbtn"  href="mapasOrdem.php" >Mapas</a>
              
          </li>
          <li class="dropdown">
            <a class="dropbtn">Catálogo</a>
            <div class="dropdown-content">
                <a href="catArmasOrdem.php">Armas</a>
                <a href="catEquipGeraisOrdem.php">Equipamentos Gerais</a>  <!-- Subtopico -->
                <a href="catItensParaOrdem.php">Itens Paranormais</a>
                <a href="catProtecaoOrdem.php">Proteção</a>
                <a href="catRituaisOrdem.php">Rituais</a>
            </div>
        </li>
      </ul>      
      </nav>
    </header>
<!-- fechando navbar -->
<!-- conteudo -->
<br/>
<br/>

<center>
<img src="images/Group 4.png" alt="banner">
</center>

<br/>
<br/>

<div className="center">
  <div className="section">
    <h2>O QUE SOMOS?</h2>
    <p>
      O Relicarium é uma plataforma web dedicada à criação, organização e personalização de
      fichas para RPGs, oferecendo uma interface intuitiva que permite aos jogadores e mestres 
      gerenciarem personagens, atributos, perícias e recursos com praticidade e clareza, tornando a 
      experiência de jogo mais fluidas.
    </p>
  </div>

<br/>
<br/>

  <div className="section">
    <h2>QUAL NOSSO OBJETIVO?</h2>
    <p>
      Atingir o público geek interessado em jogos de RPG com ou sem experiência, 
      tornando suas sessões mais dinâmicas e imersivas.
    </p>
  </div>
</div>

<br/><br/><br/><br/>

<a href="https://help.roll20.net/hc/pt/articles/360039223634-Introdu%C3%A7%C3%A3o-aos-RPGs-de-mesa#IntroductionToTabletopRPGs-WhatIsATabletopRPG?" 
target="_blank" rel="noopener noreferrer">
<img class="help"
src="images/help.png" alt="help"/>
</a>

<div class="icones-redes">
  
 <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/instagram.png" alt="Instagram" />
  </a>

  <a href="https://www.twitter.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/twitter.png" alt="Twitter" />
  </a>

  <a href="https://www.discord.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/discord.png" alt="Discord" />
  </a>
</div>

</body>

</html>