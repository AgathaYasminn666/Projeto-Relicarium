<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Relicarium</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/iventArmasOrdem.css"/>
     <link rel="icon" href="images/losangolo.png" type="image/png" />

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  </head>

  <body style="background-color: black; color: red">

  <!-- abrindo navbar -->
  <header>
    <nav>

       <a class="logo" href="index.php">RELICARIUM</a>
      <div class="mobile-menu">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
       
    
      <ul class="nav-list">
        <li class="dropdown">
            <a href="pesquisa.html">Pesquisa</a> <!-- Linkormal -->
        </li>
        <li class="dropdown">
          <a href="index.php">Home</a>
      </li>
      <li class="dropdown">
      <a class="dropbtn" href="fichaOrdem.php">Ficha</a>
    </li>
 <li class="dropdown">
        <a class="dropbtn" href="pericias.php">Perícias</a>
        </li>
    <li class="dropdown">
    <a class="dropbtn"  href="mapasOrdem.php" >Mapas</a>
              
    </li>

    <li class="dropdown">
        <a class="dropbtn">Catálogo</a>
          <div class="dropdown-content">
                <a href="catArmasOrdem.php">Armas</a>
                <a href="catEquipGeraisOrdem.php">Equipamentos Gerais</a>  <!-- Subtopico -->
                <a href="catItensParaOrdem.php">Itens Paranormais</a>
                <a href="catProtecaoOrdem.php">Proteção</a>
                <a href="catRituaisOrdem.php">Rituais</a>
          </div>
      </li>
    </ul>      
    </nav>
  </header>

  <!-- fechando navbar -->
   <!-- abrindo cadform -->

<form action="../controller/buscarProtecaoOrdem.php">
  <div class="container">
    <h1><font face="Montserat">Proteção</font></h1>
    
    <br/>

    <input type="text" id="busca" placeholder="Digite. Ex: Blusa." required>
    <div id="resultado"></div>


    <script>
    $(document).ready(function() {
      $('#busca').on('keyup', function() {
        var valor = $(this).val();
        if (valor.length > 0) {
          $.ajax({
            url: '../controller/buscarProtecaoOrdem.php',
            method: 'POST',
            data: { nome: valor },
            success: function(data) {
              $('#resultado').html(data);
            }
          });
        } else {
          $('#resultado').html('');
        }
      });
    });
  </script>

	</center>
  </div>
</form>

   <!-- fechando cadform -->

</body>
</html>