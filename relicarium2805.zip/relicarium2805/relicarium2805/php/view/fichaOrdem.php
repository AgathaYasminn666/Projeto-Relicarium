<html lang="pt-br">
  <head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Relicarium</title>
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="./css/fichaOrdem.css"/>
     <link rel="icon" href="images/losangolo.png" type="image/png" />
  </head>

  <body style="background-color: black; color: red">

  <!-- abrindo navbar -->
  <header>
    <nav>

       <a class="logo" href="index.php">RELICARIUM</a>
      <div class="mobile-menu">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
       
    
      <ul class="nav-list">
        <li class="dropdown">
            <a href="pesquisa.html">Pesquisa</a> <!-- Linkormal -->
        </li>
        <li class="dropdown">
          <a href="index.php">Home</a>
      </li>
      <li class="dropdown">
      <a class="dropbtn" href="fichaOrdem.php">Ficha</a>
    </li>
     <li class="dropdown">
        <a class="dropbtn" href="pericias.php">Perícias</a>
        </li>
    <li class="dropdown">
    <a class="dropbtn"  href="mapasOrdem.php" >Mapas</a>
             
    </li>

    <li class="dropdown">
        <a class="dropbtn">Catálogo</a>
          <div class="dropdown-content">
                <a href="catArmasOrdem.php">Armas</a>
                <a href="catEquipGeraisOrdem.php">Equipamentos Gerais</a>  <!-- Subtopico -->
                <a href="catItensParaOrdem.php">Itens Paranormais</a>
                <a href="catProtecaoOrdem.php">Proteção</a>
                <a href="catRituaisOrdem.php">Rituais</a>
          </div>
      </li>
    </ul>      
    </nav>
  </header>
  <br>
  <br>
  
  <!-- fechando navbar -->
 
  <div class="caixa-texto">
    
    <div class="campo">
      <strong>Personagem:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Jogador:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Origem:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Classe:</strong>
      <select id="select-nex" name="select-nex">
        <option value="Combatente">Combatente</option>
        <option value="Especialista">Especialista</option>
        <option value="Ocultista">Ocultista</option>
      </select>

      <strong>NEX:</strong>
      <select id="select-nex" name="select-nex">
        <option value="0%">0%</option>
        <option value="5%">5%</option>
        <option value="10%">10%</option>
        <option value="100%">100%</option>
      </select>
    </div>
<br>
    <div class="campo">
      <strong>PE por turno:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Deslocamento:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Patente:</strong>
      <select id="select-nex" name="select-nex">
        <option value="Mundano">Mundano</option>
        <option value="Recruta">Recruta</option>
        <option value="Operador">Operador</option>
        <option value="Agente especial">Agente especial</option>
        <option value="Oficial de operações">Oficial de operações</option>
        <option value="Agente de elite">Agente de elite</option>
      </select>

      <strong>Defesa:</strong>
      <input type="text" id="origem" name="origem">
    </div>
<br>
    <div class="campo">
      <strong>Bloqueio:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Esquiva:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Resistência:</strong>
      <input type="text" id="origem" name="origem">

      <strong>Proeficiência:</strong>
      <input type="text" id="origem" name="origem">
    </div>
  </div>

<br>
<br>

<!-- tabela -->
 
<div class="tabelas-lado-a-lado">

  <table class="table-atributos">
  <caption style="text-align: center; font-size: 25px;">Atributos</caption>
    <thead></thead>
    <tbody>
      <tr>
        <th style="text-align: center; font-size: 22px;">Agilidade</th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">Força</th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">Intelecto</th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">Presença</th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">Vigor</th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
    </tbody>
  </table>

  <table class="table-atributos">
  <caption style="text-align: center; font-size: 25px;">Informações</caption>
    <thead></thead>
    <tbody>
      <tr>
        <th style="text-align: center; font-size: 22px;">Vida: </th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">Sanidade: </th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
      <tr>
        <th style="text-align: center; font-size: 22px;">PE: </th>
        <td>( 1 )</td>
        <td><button type="button" class="btn btn-danger">+</button></td>
      </tr>
    </tbody>
  </table>
</body>
</html>


