// Seleciona o botão do menu mobile e a lista de navegação
const mobileMenu = document.querySelector('.mobile-menu');
const navList = document.querySelector('.nav-list');

// Adiciona um evento de clique no menu mobile
mobileMenu.addEventListener('click', () => {
  // Alterna a classe 'active' para mostrar ou esconder o menu
  navList.classList.toggle('active');
  mobileMenu.classList.toggle('active');
});
