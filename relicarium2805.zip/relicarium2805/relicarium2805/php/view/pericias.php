<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Relicarium</title>
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="./css/pericias.css"/>
  <link rel="icon" href="images/losangolo.png" type="image/png" />

</head>

<body style="background-color: black; color: red">

  <!-- Navbar -->
  <header>
    <nav>
      <a class="logo" href="index.php">RELICARIUM</a>
      <div class="mobile-menu">
        <div class="line1"></div>
        <div class="line2"></div>
        <div class="line3"></div>
      </div>
      <ul class="nav-list">
        <li class="dropdown"><a href="pesquisa.html">Pesquisa</a></li>
        <li class="dropdown"><a href="index.php">Home</a></li>
        <li class="dropdown"><a class="dropbtn" href="fichaOrdem.php">Ficha</a></li>
        <li class="dropdown"><a class="dropbtn" href="pericias.php">Perícias</a></li>
        <li class="dropdown"><a class="dropbtn" href="mapasOrdem.php">Mapas</a></li>
        <li class="dropdown">
          <a class="dropbtn">Catálogo</a>
          <div class="dropdown-content">
            <a href="catArmasOrdem.php">Armas</a>
            <a href="catEquipGeraisOrdem.php">Equipamentos Gerais</a>
            <a href="catItensParaOrdem.php">Itens Paranormais</a>
            <a href="catProtecaoOrdem.php">Proteção</a>
            <a href="catRituaisOrdem.php">Rituais</a>
          </div>
        </li>
      </ul>
    </nav>
  </header>

  <!-- Tabela de Perícias -->

   <table class="tabela pericias">
    <tr>
      <th>Perícia</th>
      <th>Atributo</th>
      <th>Treino</th>
      <th>Bônus</th>
      <th>Outros</th>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Acrobacia
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Adestramento
      </td>
      <td>PRE</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Artes
      </td>
      <td>PRE</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Atletismo
      </td>
      <td>FOR</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Atualidades
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Ciências
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Crime
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Diplomacia
      </td>
      <td>PRE</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Enganação
      </td>
      <td>PRE</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Fortitude
      </td>
      <td>VIG</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Furtividade
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Iniciativa
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Intimidação
      </td>
      <td>PRE</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Intuição
      </td>
      <td>DES</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Investigação
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Luta
      </td>
      <td>FOR</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Medicina
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Ocultismo
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Percepção
      </td>
      <td>DES</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Pilotagem
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Pontaria
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Profissão
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Reflexos
      </td>
      <td>AGI</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Religião
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Sobrevivência
      </td>
      <td>VIG</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Tática
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Tecnologia
      </td>
      <td>INT</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
    <tr>
      <td class="pericia" onclick="rolarDado(this)">
        <img src="images/dice-d20.png" alt="Dado" class="icone-dado"> Vontade
      </td>
      <td>VIG</td>
      <td><input type="text" value="0"></td>
      <td><input type="text"></td>
      <td><input type="text"></td>
    </tr>
  </table>

  <!-- script do dado -->
   
  <script>
    function rolarDado(elemento) {
      const resultado = Math.floor(Math.random() * 20) + 1;
      alert(`Dado de ${elemento.innerText}: ${resultado}`);
    }
  </script>

<br>
<br>

<a href="https://help.roll20.net/hc/pt/articles/360039223634-Introdu%C3%A7%C3%A3o-aos-RPGs-de-mesa#IntroductionToTabletopRPGs-WhatIsATabletopRPG?" 
target="_blank" rel="noopener noreferrer">
<img class="help"
src="images/help.png" alt="help"/>
</a>

<div class="icones-redes">
 <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/instagram.png" alt="Instagram" />
  </a>

  <a href="https://www.twitter.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/twitter.png" alt="Twitter" />
  </a>

  <a href="https://www.discord.com/" target="_blank" rel="noopener noreferrer">
    <img class="rede" src="images/discord.png" alt="Discord" />
  </a>
</div>



</body>
</html>
