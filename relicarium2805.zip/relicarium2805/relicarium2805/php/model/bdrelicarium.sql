-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 10/04/2025 às 00:13
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `bdrelicarium`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `armasordem`
--

CREATE TABLE `armasordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `alcance` varchar(200) NOT NULL,
  `dano` varchar(200) NOT NULL,
  `tipoDano` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `atributo` varchar(200) NOT NULL,
  `propriedade` varchar(200) NOT NULL,
  `empunhadura` varchar(200) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  `espaco` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `atributosordem`
--

CREATE TABLE `atributosordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `classeordem`
--

CREATE TABLE `classeordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(600) NOT NULL,
  `descricao` varchar(1500) DEFAULT NULL,
  `pontovida` varchar(10) NOT NULL,
  `pontosanidade` varchar(10) NOT NULL,
  `pontoesforco` varchar(10) NOT NULL,
  `poder` varchar(800) NOT NULL,
  `trilha` varchar(800) NOT NULL,
  `nex` varchar(5) NOT NULL,
  `proficiencia` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `equipgeraisordem`
--

CREATE TABLE `equipgeraisordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `espaco` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `itensparanormais`
--

CREATE TABLE `itensparanormais` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `espaco` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `modacessoriosordem`
--

CREATE TABLE `modacessoriosordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `efeito` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `modificacoesarmasordem`
--

CREATE TABLE `modificacoesarmasordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(300) NOT NULL,
  `efeito` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `modprotecoesordem`
--

CREATE TABLE `modprotecoesordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `protecao` varchar(200) NOT NULL,
  `defesa` varchar(200) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  `espaco` varchar(200) NOT NULL,
  `descricao` varchar(200) NOT NULL,
  `efeito` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `municoesordem`
--

CREATE TABLE `municoesordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(300) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `categoria` varchar(200) NOT NULL,
  `espaco` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `origemordem`
--

CREATE TABLE `origemordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL,
  `periciastreinadas` varchar(300) NOT NULL,
  `poder` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `periciasordem`
--

CREATE TABLE `periciasordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(600) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `protecoesordem`
--

CREATE TABLE `protecoesordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `defesa` varchar(200) NOT NULL,
  `categoria` varchar(200) NOT NULL,
  `espaco` varchar(200) NOT NULL,
  `penalidade` varchar(200) NOT NULL,
  `descricao` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estrutura para tabela `rituaisordem`
--

CREATE TABLE `rituaisordem` (
  `id` int(11) NOT NULL,
  `nome` varchar(200) NOT NULL,
  `descricao` varchar(300) NOT NULL,
  `alcance` varchar(200) NOT NULL,
  `dano` varchar(200) NOT NULL,
  `tipoDano` varchar(200) NOT NULL,
  `tipo` varchar(200) NOT NULL,
  `atributo` varchar(200) NOT NULL,
  `propriedade` varchar(200) NOT NULL,
  `ciclo` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `armasordem`
--
ALTER TABLE `armasordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `atributosordem`
--
ALTER TABLE `atributosordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `classeordem`
--
ALTER TABLE `classeordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `equipgeraisordem`
--
ALTER TABLE `equipgeraisordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `itensparanormais`
--
ALTER TABLE `itensparanormais`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `modacessoriosordem`
--
ALTER TABLE `modacessoriosordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `modificacoesarmasordem`
--
ALTER TABLE `modificacoesarmasordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `modprotecoesordem`
--
ALTER TABLE `modprotecoesordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `municoesordem`
--
ALTER TABLE `municoesordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `origemordem`
--
ALTER TABLE `origemordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `periciasordem`
--
ALTER TABLE `periciasordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `protecoesordem`
--
ALTER TABLE `protecoesordem`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `rituaisordem`
--
ALTER TABLE `rituaisordem`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `armasordem`
--
ALTER TABLE `armasordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `atributosordem`
--
ALTER TABLE `atributosordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `classeordem`
--
ALTER TABLE `classeordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `equipgeraisordem`
--
ALTER TABLE `equipgeraisordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `itensparanormais`
--
ALTER TABLE `itensparanormais`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `modacessoriosordem`
--
ALTER TABLE `modacessoriosordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `modificacoesarmasordem`
--
ALTER TABLE `modificacoesarmasordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `modprotecoesordem`
--
ALTER TABLE `modprotecoesordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `municoesordem`
--
ALTER TABLE `municoesordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `origemordem`
--
ALTER TABLE `origemordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `periciasordem`
--
ALTER TABLE `periciasordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `protecoesordem`
--
ALTER TABLE `protecoesordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `rituaisordem`
--
ALTER TABLE `rituaisordem`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
