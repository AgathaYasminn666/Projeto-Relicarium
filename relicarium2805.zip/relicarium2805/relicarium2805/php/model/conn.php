<?php

    class conexao{

        private $conn;

        public function __construct(){

            try{
                $this->conn = new PDO("mysql:dbname=bdrelicarium;host=localhost","root", "");
                echo "<br><br>";
            }
                catch(Exception $e){
                    echo "Erro de conexão" .$e->getMessage();
                }
        }
    }
php?>