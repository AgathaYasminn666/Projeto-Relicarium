<?php
$host = "localhost";
$user = "root";
$pass = "";
$db = "bdrelicarium"; 

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
  die("Erro na conexão: " . $conn->connect_error);
}

if (isset($_POST['nome'])) {
  $nome = $conn->real_escape_string($_POST['nome']);
  $sql = "SELECT * FROM protecaoordem WHERE nome LIKE '%$nome%'";
  $res = $conn->query($sql);

  if ($res->num_rows > 0) {
    while ($row = $res->fetch_assoc()) {
      echo "<p>" . $row['nome'] . " - " . $row['descricao'] . "</p>";
    }
  } else {
    echo "<p>Nenhum resultado encontrado.</p>";
  }
}
?>
